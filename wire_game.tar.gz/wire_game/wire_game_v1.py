from gpiozero import LED, Button
from time import time, sleep
from random import randint

LED_blue = LED(23, active_high=True, initial_value=False)
btn = Button(22)

while True:
    LED_blue.off()
    start = time()
    btn.wait_for_press()
    end = time()
    LED_blue.on()
    print('You touched the wire after',end - start, 's')
    sleep(1)
    LED_blue.off()
    print('Try again :-)')
    
