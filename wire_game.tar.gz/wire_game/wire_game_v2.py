import os 
import random
from time import sleep
from gpiozero import LED, Button

button = Button(22)
LED_Red = LED(23, active_high=True, initial_value=False)
countTouch = 0
lastTouch = 8
cycleControl = True

warnings = [ 'battle_sfx.wav', 'taught_u_well.wav', 'why_are_u_here_x.wav',
             'optimistic.wav', 'switch-off.wav', 'pointless.wav',
             'for_the_last_time.wav', 'alien_danger.wav',
             'expecting_you.wav', 'the_force.wav']


print( 'Welcome...' )
os.system( "aplay {0}".format( warnings[8] ) )
os.system( "aplay {0}".format( warnings[9] ) )
print( '\nMay The Force be with you...play\n' )

while cycleControl:    
        
    button.wait_for_press()
    LED_Red.on()
    os.system( "aplay {0}".format( warnings[countTouch] ) )
    LED_Red.off()
    countTouch += 1
    print( 'You have touched the wire', countTouch,'time(s)...',
           lastTouch - countTouch, 'left!')

    if countTouch == lastTouch :
        cycleControl = False
        LED_Red.blink(0.5, 0.5)
        print( '\nAbandon ship!!!' )
        
print( '\nEnd of game....The Empire Wins!!' )
os.system( "aplay {0}".format( warnings[countTouch-1] ) )
LED_Red.off()
    
